# Small Tools
This is a resource pack that makes tools smaller in your hands.

Changes every type of: shovel, pickaxe, axe, hoe, sword. Also: bow, crossbow, trident.
